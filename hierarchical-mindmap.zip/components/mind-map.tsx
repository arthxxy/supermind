"use client"

import { useEffect, useRef, useState } from "react"
import * as d3 from "d3"
import { NodeToolbar } from "@/components/node-toolbar"
import { Button } from "@/components/ui/button"
import { PlusCircle } from "lucide-react"

// Define types for our nodes and links
interface Node extends d3.SimulationNodeDatum {
  id: string
  name: string
  level: number
  color?: string
  x?: number
  y?: number
}

interface Link extends d3.SimulationLinkDatum<Node> {
  source: string | Node
  target: string | Node
  type: "parent-child" | "friend"
}

interface GraphData {
  nodes: Node[]
  links: Link[]
}

// Initial data for the mindmap
const initialData: GraphData = {
  nodes: [
    { id: "root", name: "Main Concept", level: 0, color: "#ff6b6b" },
    { id: "child1", name: "Sub-concept 1", level: 1, color: "#48dbfb" },
    { id: "child2", name: "Sub-concept 2", level: 1, color: "#48dbfb" },
    { id: "child3", name: "Sub-concept 3", level: 1, color: "#48dbfb" },
    { id: "grandchild1", name: "Detail 1.1", level: 2, color: "#1dd1a1" },
    { id: "grandchild2", name: "Detail 1.2", level: 2, color: "#1dd1a1" },
    { id: "grandchild3", name: "Detail 2.1", level: 2, color: "#1dd1a1" },
    { id: "grandchild4", name: "Detail 3.1", level: 2, color: "#1dd1a1" },
  ],
  links: [
    { source: "root", target: "child1", type: "parent-child" },
    { source: "root", target: "child2", type: "parent-child" },
    { source: "root", target: "child3", type: "parent-child" },
    { source: "child1", target: "grandchild1", type: "parent-child" },
    { source: "child1", target: "grandchild2", type: "parent-child" },
    { source: "child2", target: "grandchild3", type: "parent-child" },
    { source: "child3", target: "grandchild4", type: "parent-child" },
    { source: "grandchild1", target: "grandchild3", type: "friend" },
    { source: "child1", target: "child2", type: "friend" },
  ],
}

export default function MindMap() {
  const [graphData, setGraphData] = useState<GraphData>(initialData)
  const [selectedNode, setSelectedNode] = useState<Node | null>(null)
  const [toolbarPosition, setToolbarPosition] = useState({ x: 0, y: 0 })
  const svgRef = useRef<SVGSVGElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const simulationRef = useRef<d3.Simulation<Node, Link> | null>(null)

  // Function to add a new node
  const addNode = (parentId?: string) => {
    const newNodeId = `node-${Date.now()}`
    const parentNode = parentId ? graphData.nodes.find((node) => node.id === parentId) : null

    const newLevel = parentNode ? parentNode.level + 1 : 0
    const colors = ["#ff6b6b", "#48dbfb", "#1dd1a1", "#feca57", "#54a0ff"]

    const newNode: Node = {
      id: newNodeId,
      name: `New Node ${graphData.nodes.length + 1}`,
      level: newLevel,
      color: colors[newLevel % colors.length],
    }

    const newLink = parentNode ? { source: parentId, target: newNodeId, type: "parent-child" as const } : null

    setGraphData((prev) => ({
      nodes: [...prev.nodes, newNode],
      links: newLink ? [...prev.links, newLink] : prev.links,
    }))
  }

  // Function to delete a node
  const deleteNode = (nodeId: string) => {
    setGraphData((prev) => ({
      nodes: prev.nodes.filter((node) => node.id !== nodeId),
      links: prev.links.filter(
        (link) =>
          (typeof link.source === "string" ? link.source !== nodeId : link.source.id !== nodeId) &&
          (typeof link.target === "string" ? link.target !== nodeId : link.target.id !== nodeId),
      ),
    }))
    setSelectedNode(null)
  }

  // Function to add a friend connection
  const addFriendLink = (sourceId: string, targetId: string) => {
    // Check if link already exists
    const linkExists = graphData.links.some(
      (link) =>
        ((typeof link.source === "string" ? link.source === sourceId : link.source.id === sourceId) &&
          (typeof link.target === "string" ? link.target === targetId : link.target.id === targetId)) ||
        ((typeof link.source === "string" ? link.source === targetId : link.source.id === targetId) &&
          (typeof link.target === "string" ? link.target === sourceId : link.target.id === sourceId)),
    )

    if (!linkExists && sourceId !== targetId) {
      setGraphData((prev) => ({
        ...prev,
        links: [...prev.links, { source: sourceId, target: targetId, type: "friend" }],
      }))
    }
  }

  // Update node name
  const updateNodeName = (nodeId: string, newName: string) => {
    setGraphData((prev) => ({
      ...prev,
      nodes: prev.nodes.map((node) => (node.id === nodeId ? { ...node, name: newName } : node)),
    }))
  }

  // Handle node click
  const handleNodeClick = (node: Node, event: MouseEvent) => {
    setSelectedNode(node)

    // Calculate position for the toolbar
    if (containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect()
      setToolbarPosition({
        x: event.clientX - rect.left,
        y: event.clientY - rect.top,
      })
    }
  }

  // Handle background click to deselect
  const handleBackgroundClick = () => {
    setSelectedNode(null)
  }

  // Initialize and update the D3 visualization
  useEffect(() => {
    if (!svgRef.current || !containerRef.current) return

    const width = containerRef.current.clientWidth
    const height = containerRef.current.clientHeight
    const svg = d3.select(svgRef.current)

    // Clear previous content
    svg.selectAll("*").remove()

    // Create the main group for the graph
    const g = svg.append("g")

    // Create zoom behavior
    const zoom = d3
      .zoom<SVGSVGElement, unknown>()
      .scaleExtent([0.1, 4])
      .on("zoom", (event) => {
        g.attr("transform", event.transform)
      })

    svg.call(zoom)
    svg.on("click", handleBackgroundClick)

    // Center the view initially
    svg.call(zoom.transform, d3.zoomIdentity.translate(width / 2, height / 2))

    // Create the simulation
    const simulation = d3
      .forceSimulation<Node, Link>(graphData.nodes)
      .force(
        "link",
        d3
          .forceLink<Node, Link>(graphData.links)
          .id((d) => d.id)
          .distance((link) => (link.type === "friend" ? 100 : 60))
          .strength((link) => (link.type === "friend" ? 0.1 : 0.8)),
      )
      .force("charge", d3.forceManyBody().strength(-300))
      .force("center", d3.forceCenter(0, 0))
      .force("radial", d3.forceRadial<Node>((d) => 100 * d.level, 0, 0).strength(0.8))

    simulationRef.current = simulation

    // Create the links
    const link = g
      .append("g")
      .attr("stroke", "#999")
      .attr("stroke-opacity", 0.6)
      .selectAll("line")
      .data(graphData.links)
      .join("line")
      .attr("stroke-width", (d) => (d.type === "parent-child" ? 2 : 1))
      .attr("stroke-dasharray", (d) => (d.type === "friend" ? "5,5" : null))

    // Add arrowheads for parent-child links
    svg
      .append("defs")
      .append("marker")
      .attr("id", "arrowhead")
      .attr("viewBox", "0 -5 10 10")
      .attr("refX", 20)
      .attr("refY", 0)
      .attr("orient", "auto")
      .attr("markerWidth", 6)
      .attr("markerHeight", 6)
      .append("path")
      .attr("d", "M0,-5L10,0L0,5")
      .attr("fill", "#999")

    // Apply arrowheads to parent-child links
    link.filter((d) => d.type === "parent-child").attr("marker-end", "url(#arrowhead)")

    // Create node groups
    const node = g
      .append("g")
      .selectAll(".node")
      .data(graphData.nodes)
      .join("g")
      .attr("class", "node")
      .on("click", (event, d) => {
        event.stopPropagation()
        handleNodeClick(d, event)
      })
      .call(
        d3
          .drag<SVGGElement, Node>()
          .on("start", (event, d) => {
            if (!event.active) simulation.alphaTarget(0.3).restart()
            d.fx = d.x
            d.fy = d.y
          })
          .on("drag", (event, d) => {
            d.fx = event.x
            d.fy = event.y
          })
          .on("end", (event, d) => {
            if (!event.active) simulation.alphaTarget(0)
            d.fx = null
            d.fy = null
          }),
      )

    // Add circles to nodes
    node
      .append("circle")
      .attr("r", 8)
      .attr("fill", (d) => d.color || "#999")

    // Add text labels
    node
      .append("text")
      .attr("dx", 12)
      .attr("dy", 4)
      .text((d) => d.name)
      .attr("font-size", "12px")
      .attr("font-family", "sans-serif")

    // Update positions on each tick
    simulation.on("tick", () => {
      link
        .attr("x1", (d) => (typeof d.source === "string" ? 0 : d.source.x || 0))
        .attr("y1", (d) => (typeof d.source === "string" ? 0 : d.source.y || 0))
        .attr("x2", (d) => (typeof d.target === "string" ? 0 : d.target.x || 0))
        .attr("y2", (d) => (typeof d.target === "string" ? 0 : d.target.y || 0))

      node.attr("transform", (d) => `translate(${d.x || 0},${d.y || 0})`)
    })

    // Handle window resize
    const handleResize = () => {
      if (containerRef.current) {
        const newWidth = containerRef.current.clientWidth
        const newHeight = containerRef.current.clientHeight
        svg.attr("width", newWidth).attr("height", newHeight)
      }
    }

    window.addEventListener("resize", handleResize)

    return () => {
      window.removeEventListener("resize", handleResize)
      simulation.stop()
    }
  }, [graphData])

  return (
    <div ref={containerRef} className="relative w-full h-full">
      <svg ref={svgRef} width="100%" height="100%" />

      {selectedNode && (
        <NodeToolbar
          node={selectedNode}
          position={toolbarPosition}
          onAddChild={() => addNode(selectedNode.id)}
          onDelete={() => deleteNode(selectedNode.id)}
          onUpdateName={(name) => updateNodeName(selectedNode.id, name)}
          onAddFriend={(targetId) => addFriendLink(selectedNode.id, targetId)}
          nodes={graphData.nodes.filter((n) => n.id !== selectedNode.id)}
        />
      )}

      <div className="absolute bottom-4 right-4">
        <Button onClick={() => addNode()} variant="outline" size="sm">
          <PlusCircle className="mr-2 h-4 w-4" />
          Add Root Node
        </Button>
      </div>
    </div>
  )
}
