"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Trash2, Plus, LinkIcon, Edit2 } from "lucide-react"

interface Node {
  id: string
  name: string
  level: number
  color?: string
  x?: number
  y?: number
}

interface NodeToolbarProps {
  node: Node
  position: { x: number; y: number }
  onAddChild: () => void
  onDelete: () => void
  onUpdateName: (name: string) => void
  onAddFriend: (targetId: string) => void
  nodes: Node[]
}

export function NodeToolbar({
  node,
  position,
  onAddChild,
  onDelete,
  onUpdateName,
  onAddFriend,
  nodes,
}: NodeToolbarProps) {
  const [isEditing, setIsEditing] = useState(false)
  const [newName, setNewName] = useState(node.name)
  const [isLinking, setIsLinking] = useState(false)
  const [selectedNodeId, setSelectedNodeId] = useState("")

  const handleNameSave = () => {
    onUpdateName(newName)
    setIsEditing(false)
  }

  const handleAddFriend = () => {
    if (selectedNodeId) {
      onAddFriend(selectedNodeId)
      setIsLinking(false)
      setSelectedNodeId("")
    }
  }

  // Filter nodes to only show potential friends (same level)
  const potentialFriends = nodes.filter((n) => n.level === node.level)

  return (
    <div
      className="absolute bg-white shadow-lg rounded-lg p-3 z-10 flex flex-col gap-2 min-w-[200px]"
      style={{
        left: `${position.x}px`,
        top: `${position.y}px`,
        transform: "translate(-50%, -100%) translateY(-10px)",
      }}
    >
      <div className="text-sm font-medium mb-1">
        {isEditing ? (
          <div className="flex gap-2">
            <Input value={newName} onChange={(e) => setNewName(e.target.value)} size={20} className="h-8" />
            <Button size="sm" onClick={handleNameSave} className="h-8">
              Save
            </Button>
          </div>
        ) : (
          <div className="flex justify-between items-center">
            <span>{node.name}</span>
            <Button variant="ghost" size="sm" onClick={() => setIsEditing(true)} className="h-6 w-6 p-0">
              <Edit2 size={14} />
            </Button>
          </div>
        )}
      </div>

      <div className="flex gap-2">
        <Button size="sm" onClick={onAddChild} className="flex-1">
          <Plus size={14} className="mr-1" /> Add Child
        </Button>
        <Button size="sm" variant="destructive" onClick={onDelete} className="flex-1">
          <Trash2 size={14} className="mr-1" /> Delete
        </Button>
      </div>

      {isLinking ? (
        <div className="flex flex-col gap-2">
          <Select value={selectedNodeId} onValueChange={setSelectedNodeId}>
            <SelectTrigger className="h-8">
              <SelectValue placeholder="Select a node" />
            </SelectTrigger>
            <SelectContent>
              {potentialFriends.length > 0 ? (
                potentialFriends.map((n) => (
                  <SelectItem key={n.id} value={n.id}>
                    {n.name}
                  </SelectItem>
                ))
              ) : (
                <SelectItem value="none" disabled>
                  No available nodes
                </SelectItem>
              )}
            </SelectContent>
          </Select>
          <div className="flex gap-2">
            <Button size="sm" onClick={handleAddFriend} disabled={!selectedNodeId} className="flex-1">
              Connect
            </Button>
            <Button size="sm" variant="outline" onClick={() => setIsLinking(false)} className="flex-1">
              Cancel
            </Button>
          </div>
        </div>
      ) : (
        <Button size="sm" variant="outline" onClick={() => setIsLinking(true)} disabled={potentialFriends.length === 0}>
          <LinkIcon size={14} className="mr-1" /> Add Friend Connection
        </Button>
      )}
    </div>
  )
}
